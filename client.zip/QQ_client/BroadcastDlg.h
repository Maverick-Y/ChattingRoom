﻿#pragma once


// BroadcastDlg

class BroadcastDlg : public CWnd
{
	DECLARE_DYNAMIC(BroadcastDlg)

public:
	BroadcastDlg();
	virtual ~BroadcastDlg();

protected:
	DECLARE_MESSAGE_MAP()
};


