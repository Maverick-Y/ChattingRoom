﻿// BroadcastDlg.cpp: 实现文件
//

#include "pch.h"
#include "QQ_client.h"
#include "BroadcastDlg.h"


// BroadcastDlg

IMPLEMENT_DYNAMIC(BroadcastDlg, CWnd)

BroadcastDlg::BroadcastDlg()
{

}

BroadcastDlg::~BroadcastDlg()
{
}


BEGIN_MESSAGE_MAP(BroadcastDlg, CWnd)
END_MESSAGE_MAP()



// BroadcastDlg 消息处理程序


