﻿// broadcast.cpp: 实现文件
//

#include "pch.h"
#include "QQ_client.h"
#include "broadcast.h"
#include "afxdialogex.h"


// broadcast 对话框

IMPLEMENT_DYNAMIC(broadcast, CDialogEx)

broadcast::broadcast(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_BROADCAST, pParent)
{

}

broadcast::~broadcast()
{
}

void broadcast::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(broadcast, CDialogEx)
END_MESSAGE_MAP()


// broadcast 消息处理程序
